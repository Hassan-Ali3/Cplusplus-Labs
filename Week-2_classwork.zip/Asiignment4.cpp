/*Fundamentals of Programming-Lab
BS-AI 
Section-C
Week 2 Assignment
Code written by:Hassan Ali Soomro
Date:26/08/2023
*/

#include<iostream>
using namespace std;
int main()
{
cout<<"%%%%%%\n";
cout<<" %%%\n";
cout<<"  %\n";
cout<<" %%%\n";
cout<<"%%%%%";

system("pause");
return 0;
}



