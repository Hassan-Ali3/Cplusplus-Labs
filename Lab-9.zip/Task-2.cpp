/*******************
	Programming Fundamentals-Lab
	Lab-9
	Code written By: Hassan Ali
*******************/
#include <iostream>
using namespace std ;
int main()
{
	int aar[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	for(int i=0 ; i<10 ; i++){
		
	}




	system("Pause") ;
	return 0 ;
}

