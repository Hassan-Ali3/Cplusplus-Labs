	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	Week 6 
	Class Work
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
	#include <iostream>
	using namespace std ;
	int main()
	{
	int speed , speedlimit ;
	cout << "Enter the speed of vehicle(Kmh): " ;
	cin >> speed ;
	cout << "Enter the speed limit (Kmh): " ;
	cin >> speedlimit ;
	if ( speed > speedlimit ){
		cout << "You are out of speed limit. You are fined $10." << endl ;
	}
	else{
		cout << "You are within the speed limit. No fine is imposed." << endl ;
	}
	system("pause");
	return 0 ;
	}

