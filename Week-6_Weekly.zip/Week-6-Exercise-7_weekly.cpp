	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	Week 5 
	Class Work
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
	#include <iostream>
	using namespace std ;
	int main()
	{
	int num ;
	cout << "Enter any number: " ;
	cin >> num ;
	if ( num > 0 ) {
		cout << num << " is a positive number." << endl ;
	}
	else if ( num < 0 ) {
		cout << num << " is a negative number." << endl ;
	}
	else {
		cout << num << " is zero" << endl ;
	}
	system("pause");
	return 0 ;
	}

