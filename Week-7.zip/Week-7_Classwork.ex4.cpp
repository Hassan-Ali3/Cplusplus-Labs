	/*******************
	Programming Fundamentals 
	BS-AI Section-C
	Week-7
	Classwork
	Coded by: Hassan ALi
	*//////////////////////
	#include <iostream>
	using namespace std ;
	int main()
	{
	int N , W , O , E ;
	cout << "Whole Numbers: " ;
	for ( W=0 ; W<=9 ; W++  )
	{ cout << " " << W ;
	}
	cout << endl << "Whole Numbers: " ;	
	for ( N=1 ; N<=10 ; N++  )
	{ cout << " " << W ;
	}
	cout << endl << "Odd Numbers: " ;
	for ( O=1 ; O<=19 ; O+=2  )
	{ cout << " " << O ;
	}cout << endl << "Even Numbers: " ;
	for ( E=0 ; E<=20 ; E+=2 )
	{ cout << " " << E ;
	}
	cout << endl ;
	system("pause");
	return 0 ;
	}

