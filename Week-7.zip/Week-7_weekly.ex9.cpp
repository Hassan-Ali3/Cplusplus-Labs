	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	Week 7 
	Weekly Tasks
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
	#include <iostream>
	using namespace std ;
	int main()
	{
	int N ;
	cout << "Enter a positive value for N: ";
    cin >> N;    
	int i=N ;
	cout << "---------------------------------------\n" ;    
    cout << "**Using \"for\" loop** " << endl ;
	for ( int i=N ; i >= 1; i) {
		cin >> i ;
    }
	cout << "\n---------------------------------------\n" ;
    cout << "**Using \"while\" loop** " << endl ;
    while (!(i == 0)){
    	cin >> i ;
    	i ;
	}
	cout << endl << endl ;
	system("pause");
	return 0 ;
	}

