	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	Week 7 
	Class Work
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
	#include <iostream>
	using namespace std ;
	int main()
	{
//	cout<<x<<", "<<<<<endl;
	int x, y;
//	cout<<x<<", "<<y<<endl;
	x = 5, y = 9;
	cout << x <<", " << y << endl ;
	cout << x++ <<", " << y << endl ;
	cout<< x << ", " << y << endl ;	
	cout << ++x << ", " << y++ << endl ;
	++x ;
	y = 6 ;
	cout << ++x << ", " << y++ << endl ; 
	cout << x++ << ", " << ++y << endl ;
	x = x + 1 ;// x++ or x += 1
	y + 2 ; // y = y + 2
	cout << ++x << ", " << y++ <<endl ;
	cout << x << ", " << y << endl ;

	system("pause");
	return 0 ;
	}

