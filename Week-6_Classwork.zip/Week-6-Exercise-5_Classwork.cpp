	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	Week 5 
	Class Work
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
	#include <iostream>
	using namespace std ;
	int main()
	{
	int num ;
	cout << "Enter any number: " ;
	cin >> num ;
	if ( num % 2 == 0 ) {
		cout << num << "is an even number." << endl ;
	}
	else if ( num % 2 == 1 ) {
		cout << num << " is an odd number." << endl ;
}
	system("pause");
	return 0 ;
	}

