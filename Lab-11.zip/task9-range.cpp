	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	lab-11
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
#include <iostream>
using namespace std ;

int range(int) ;

int main(){
	int num ;
	cout << "Enter a positive integer range: " ;
	cin >> num ;
	
	cout << "Sum of positive numbers upto " << num << " is: " << range(num) << endl ;
	
	system ("Pause");
	return 0 ;
}

int range(int a) 
{
	int b ;
	for(int i=a ; i>=1 ; i--){
		b+= i ;
	}
	return b ;
}
	
