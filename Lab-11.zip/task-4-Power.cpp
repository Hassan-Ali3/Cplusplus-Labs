	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	lab-11
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 

#include <iostream>
using namespace std ;

double power(float , int) ;

int main(){
	
	float base ;
	int pow ;
	
	cout << "Enter the base: " ;
	cin >> base ;
	cout << "Enter the exponent (int): " ;
	cin >> pow ;
	
	cout << base << " ^ " << pow << " = " ;
	cout << power (base , pow) << endl ;
	
	system ("Pause");
	return 0 ;
}

double power (float a , int b) 
{
	double c=1 ;
	for(int i=1 ; i<=b ; i++){
		c = c * a ;
	}
	return c ;
}
