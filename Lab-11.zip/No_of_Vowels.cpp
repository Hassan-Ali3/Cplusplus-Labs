	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	lab-11
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
#include <iostream>
using namespace std ;

int noVowel (string) ;

int main()
{
	string Str ;
	int num ;

	cout <<	"Enter a sequence of characters: " ;
	getline(cin , Str) ;

	cout << "The number of Vowels in the sequence are: " << noVowel(Str) << endl ;

	system ("Pause");
	return 0 ;
}

int noVowel(string ch)
{
	int num ;
	
	for(int i=0 ; i<ch.length() ; i++)
	{
		ch[i] = tolower(ch[i]) ;
		if(ch[i] == 'a' || ch[i] == 'e' || ch[i] == 'i' || ch[i] == 'o' || ch[i] == 'u'){
		num++ ;
	}
  }
	return num ;
}
