#include <iostream>
using namespace std ;
bool isVowel(char ch) ;

int main() {
 
    char inputChar;
    cout << "Enter a character: ";
    cin >> inputChar;

 
    if (isVowel(inputChar)) {
        cout << inputChar << " is a vowel." << endl;
    } else {
        cout << inputChar << " is not a vowel." << endl;
    }

    return 0;
}
bool isVowel(char ch) {
    char lowercaseCh = tolower(ch);

    return (lowercaseCh == 'a' || lowercaseCh == 'e' || lowercaseCh == 'i' || lowercaseCh == 'o' || lowercaseCh == 'u');
} 

