	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	lab-11
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
#include <iostream>
using namespace std ;

long long factorial (int) ;

int main(){
	
	unsigned int num ;
	cout << "Enter any number to find its factorial: " ;
	cin >> num ;
	
	cout << "The factorial of " << num << " is " << factorial (num) << endl ;
	
	system ("Pause");
	return 0 ;
}

long long factorial (int a) 
{	
	long long b=1 ;
	for(int i=1 ; i<=a ; i++)	{
		b = b * i ;
	}
	return b ;
}
