	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	lab-11
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
#include <iostream>
using namespace std ;

double percentage (float , float) ;

int main(){
	float obtMarks , totMarks;
	cout << "Enter the obtained marks: " ;
	cin >> obtMarks ;
	cout << "Enter the total marks: " ;
	cin >> totMarks ;
	
	cout << "Percentage: " << percentage(obtMarks , totMarks) << "%" << endl ;
	
	system ("Pause");
	return 0 ;
}

double percentage (float a , float b) 
{
	return (a/b)*100 ;
}
