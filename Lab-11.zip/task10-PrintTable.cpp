	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	lab-11
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
#include <iostream>
using namespace std ;
 
void printTable (int) ;

int main(){
	int num ;
	cout << "Enter any number to print its number: " ;
	cin >> num ;
	printTable (num) ;
	system ("Pause");
	return 0 ;
}

void printTable (int a) 
{
	for (int i=1 ; i<=10 ; i++){
		cout << a << " x " << i << " = " << a*i << endl ;
	}
}
