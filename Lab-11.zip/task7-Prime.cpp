	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	lab-11
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
#include <iostream>
using namespace std ;

bool isPrime (int) ;
int main(){
	int num ;
	cout << "Enter the number to check whether the number is prime or not: " ;
	cin >> num ;
	
	if(isPrime(num))
	cout << "The number is Prime." << endl ;
	else
	cout << "The number is not Prime." << endl ;
	
	system ("Pause");
	return 0 ;
}

bool isPrime (int a) 
{
	bool prime = true;
	for(int i=2 ; i<a ; i++ )	
	{
		if( a%i==0)
		prime =  false ;
		
	}
	return prime;
}
