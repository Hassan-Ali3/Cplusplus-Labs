	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	lab-11
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*/////////////////////////

#include <iostream>
using namespace std ;

int printTable (int a , int b) ;

int main(){
	int num , range ;
	
	cout << "Enter the number to print its table: " ;
	cin >> num ;
	cout << "Enter the final range value: " ;
	cin >> range ;

	cout << printTable (num , range) ;
	
	system ("Pause");
	return 0 ;
}

int printTable (int a , int b) 
{
	for (int i=1 ; i<=b ; i++){
		cout << a << " x " << i << " = " << a*i << endl ;
	}
}

