	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	lab-11
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 

#include <iostream>
using namespace std ;
int addition (int a , int b) ;
int multiplication (int , int) ;
int substraction (int , int) ;
int division (int , int) ;
int mode (int , int) ;

int main()
{
	int num1 , num2 ;
	
	cout << "Enter the first number: " ;
	cin >> num1 ;
	cout << "Enter the second number: " ;
	cin >> num2 ;
	cout << "Addition: " << addition (num1 , num2) << endl ;	
	cout << "Subtraction: " << substraction (num1 , num2) << endl ;
	cout << "Multiplication: " << multiplication (num1 , num2) << endl ;
	cout << "Division: " << division (num1 , num2) << endl ;
	cout << "Modulus: " << mode (num1 , num2) << endl ;
	system ("Pause");
	return 0 ;
}

int addition (int a , int b) 
{
	return a + b ;
}

int substraction (int a , int b){
	return a - b ;
}

int multiplication (int a , int b){
	return b * a ;
}

int division (int a , int b){
	return a / b ;
}

int mode (int a , int b){
	return a % b ;
}
