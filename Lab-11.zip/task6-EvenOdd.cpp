	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	lab-11
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
#include <iostream>
using namespace std ;

void numType (int) ;

int main(){
	int num ;
	cout << "Enter the number: " ;
	cin >> num ;
	
	numType(num) ;
	
	system ("Pause");
	return 0 ;
}

void numType (int a) 
{
	if( a%2 == 0){
		cout << "Even" << endl ;
	}
	else {
		cout << "Odd" << endl ;
	}	
}
