#include <iostream>
#include<iomanip>
using namespace std;
int main(){
cout<<"Hello"<<endl;
cout<<setw(22)<<"Hello"<<endl;
cout<<setw(40)<<"Hello"<<endl;

system("pause");
return 0;
}

