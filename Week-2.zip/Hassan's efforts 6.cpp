#include <iostream>
#include <iomanip>
using namespace std;
int main(){
cout<<"Programming language makes use of different operators that are:"<<endl;
cout<<setw(50)<<"Logical Operator\\Relational Operator\\";


system("pause");

return 0;
}

