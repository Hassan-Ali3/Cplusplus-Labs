#include <iostream>
#include <iomanip>
using namespace std;
int main(){
cout<<setw(20)<<"* * * * * * * * * * * *"<<endl;
cout<<"*"<<setw(22)<<"*"<<endl;
cout<<"*"<<setw(22)<<"*"<<endl;
cout<<"*"<<setw(22)<<"*"<<endl;
cout<<setw(21)<<"* * * * * * * * * * * *"<<endl;
system("pause");


return 0;
}

