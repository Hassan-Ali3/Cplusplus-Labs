#include <iostream>
#include<iomanip>
using namespace std;
int main(){
cout<<"students"<<setw(10)<<"English"<<setw(8)<<"Maths"<<setw(7)<<"ICT"<<setw(15)<<"Programming"<<endl;
cout<<"Tom"<<setw(14)<<"40.00"<<setw(9)<<"95.00"<<setw(9)<<"94.00"<<setw(9)<< "54.00"<<endl;
cout<<"Jerry"<<setw(12)<<"15.60"<<setw(9)<<"34.00"<<setw(9)<<"43.00"<<setw(9)<< "67.00"<<endl;
cout<<"Tweety"<<setw(11)<<"30.00"<<setw(9)<<"46.67"<<setw(9)<<"46.00"<<setw(9)<< "32.67"<<endl;
cout<<"Bunny"<<setw(12)<<"25.00"<<setw(9)<<"12.00"<<setw(9)<<"23.00"<<setw(9)<< "12.00"<<endl;
cout<<"Dora"<<setw(13)<<"50.00"<<setw(9)<<"56.00"<<setw(9)<<"85.00"<<setw(9)<< "45.00"<<endl;
cout<<"Donald"<<setw(11)<<"79.00"<<setw(9)<<"89.00"<<setw(9)<<"78.79"<<setw(9)<< "12.00"<<endl;
system("pause");










return 0;
}

