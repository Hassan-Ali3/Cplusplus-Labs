#include <iostream>
#include <iomanip>
using namespace std;
int main(){
cout<<setw(15)<<"*" <<endl;
cout<<setw(14)<<"*"<<setw(2 )<<"*"<<endl;
cout<<setw(13)<<"*"<<setw(4)<<"*"<<endl;
cout<<setw(12)<<"*"<<setw(6)<<"*"<<endl;
cout<<setw(11)<<"*"<<setw(8)<<"*"<<endl;
cout<<setw(10)<<"*"<<setw(10)<<"*"<<endl;
cout<<setw(9)<<"*"<<setw(12)<<"*"<<endl;
cout<<setw(10)<<"*"<<setw(10)<<"*"<<endl;
cout<<setw(11)<<"*"<<setw(8)<<"*"<<endl;
cout<<setw(12)<<"*"<<setw(6)<<"*"<<endl;
cout<<setw(13)<<"*"<<setw(4)<<"*"<<endl;
cout<<setw(14)<<"*"<<setw(2 )<<"*"<<endl;
cout<<setw(15)<<"*" <<endl;
system("pause");


return 0;
}

