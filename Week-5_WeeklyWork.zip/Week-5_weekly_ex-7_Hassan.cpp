	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	Week 5 
	Class Work
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
	#include <iostream>
	using namespace std ;
	int main()
	{
	int score ;
	cout << "Enter the test score of the student: "	;
	cin >> score ;
	cout << "Whether student has passed the test or not? " << (score >= 60) << endl ;
	
	system("pause") ;
	return 0 ;
	}
	

