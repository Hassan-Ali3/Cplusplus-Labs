	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	Week 5 
	Class Work
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
	#include <iostream>
	using namespace std ;
	int main()
	{
	int age ;
	
	cout << "Enter the age of the person: " ;
	cin >> age ;
	cout << "Whether the person is eligible to vote or not? " << (age >= 18) << endl;
	
	system("pause") ;
	return 0 ;
	}
	

