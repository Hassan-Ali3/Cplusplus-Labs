	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	Week 5 
	Class Work
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
	#include <iostream>
	using namespace std ;
	int main()
	{
	float a = 4 , b = 0.0 , y = 1 , c = 3 ;
	cout << ((4 * a * y )/ c - (a * y)/ c ) << endl;
	
	a = 2.2 , c = 4.1, y = 3.0 ;
	cout << (c + (a * y * y)/ b) << endl ;
	system("pause") ;
	return 0 ;
	}
	

