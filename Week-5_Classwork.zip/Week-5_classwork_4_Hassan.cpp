	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	Week 5 
	Class Work
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
	#include<iostream>
	using namespace std;
	int main()
	{
	float x , z ;
	cout << "Input any value of x: " ;
	cin >> x ;
	x += 2 * 3 - 1 ;
	cout << "x += 2 * 3 - 1 = " << x << endl;
	cout << "-------------------------" << endl << endl ;
	cout << "Input any value of z: " ; 
	cin >> z ;
	z += 5 % 3 /  8 * 3 + 4  ; 
	cout << "z += 5 % 3 /  8 * 3 + 4 = " << z << endl ;

	system("pause");
	return 0;
}



