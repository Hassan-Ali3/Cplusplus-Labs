	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	Week 5 
	Class Work
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
	
	#include<iostream>
	using namespace std;
	int main()
	{
	float temp ;
	bool range ;
	
	cout << "Input any temperature: " ; 
	cin >> range ;
	
	range = temp >=68 && temp <=72 ;
	cout << "Does the temperature fall in comfortable range or not ? " << range << endl ;

	system("pause");
	return 0;
}



