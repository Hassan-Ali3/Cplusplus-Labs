	/********************
	Progrsmming Fundamentals- lab
	BS AI Section (C)
	Week 5 
	Class Work
	Instructor: Nimra Mughal
	Code written By: Hassan Ali
	*///////////////////////// 
	#include<iostream>
	using namespace std;
	int main()
{
	int year ;
	cout << "Inter any year: " ;
	cin >> year ;
	
	bool exp = year % 4 == 0 ;
	cout << "Whether the year is leap or not ? " << exp << endl ;

	system("pause");
	return 0;
}



