#include<iostream>
using namespace std;
int main()
{

cout<<"\t\t		 *\n"; 
cout<<"\t                  	***\n";
cout<<"\t		       *****\n";	
cout<<"\t		      *******\n";
cout<<"\t		     *********\n";
cout<<"\t		    ***********\n";
cout<<"\t		   *************\n";
cout<<"\t                  ***************\n";
cout<<"\t		 *****************\n";
cout<<"\t	       	  ****************\n";
cout<<"\t		   **************\n";
cout<<"\t                    ***********\n";
cout<<"\t       		     *********\n";
cout<<"\t      		      *******\n";
cout<<"\t       		       *****\n";
cout<<"\t\t     		***\n";
cout<<"\t\t      		 *";





system("pause");
return 0;
}



