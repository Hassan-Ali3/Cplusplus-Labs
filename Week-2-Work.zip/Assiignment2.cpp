/*Fundamentals of Programming-Lab
BS-AI 
Section-C
Week 2 Assignment
Code written by:Hassan Ali Soomro
Date:26/08/2023
*/

#include<iostream>
using namespace std;
int main()
{
cout<<"								\t*\n";// Very difficult to understand it 
cout<<"							\t	*	*\n\t\t";// it took me hours to solve
cout<<"*	*	*	*	*	*	*	*	*	*\n\t";// but finally it's done
cout<<"								*	*\n\t\t\t	";
cout<<"  	             			* 	";


system("pause");
return 0;
}



