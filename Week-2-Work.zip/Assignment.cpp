#include<iostream>
using namespace std;
int main(){
cout<<"4 3 2 1\n"; 
cout<<"3 2 1\n";
cout<<"2 1\n";
cout<<"1";



system("pause");
 return 0;
}


