/*Fundamentals of Programming-Lab
Week 2 Assignment
Code written by:Hassan Ali Soomro
Date:26/08/2023
*/
#include<iostream>
using namespace std;
int main()
{
cout<<("###########################");
cout<<("\n## HASSAN  ALI  SOOMRO ##");
cout<<("\n#########################");





system("pause");
return 0;
}


